import ClassComponent from "./ClassComponent";



export default function College() {


  return (
 <div style={{backgroundColor:'orange',padding:'10px'}}>
  <h1> College Component</h1>
  <ClassComponent/>
 </div>
  )
}


