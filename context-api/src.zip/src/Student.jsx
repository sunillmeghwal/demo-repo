import Subject from "./Subject";



export default function Student() {


  return (
 <div style={{backgroundColor:'green',padding:'10px'}}>
  <h1> Student Component</h1>
  <Subject/>
 </div>
  )
}


