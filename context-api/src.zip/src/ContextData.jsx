import { createContext } from "react";


 export const SubjectContext =createContext();