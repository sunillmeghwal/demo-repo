import Student from "./Student";



export default function ClassComponent() {


  return (
 <div style={{backgroundColor:'skyblue',padding:'10px'}}>
  <h1> ClassComponent</h1>
  <Student/>
 </div>
  )
}


